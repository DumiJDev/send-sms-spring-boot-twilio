package org.github.dumijdev.microservice.testmessagetwilioservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TestMessageTwilioServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
