package org.github.dumijdev.microservice.receivemessagetwilioservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ReceiveMessageTwilioServiceApplication

fun main(args: Array<String>) {
	runApplication<ReceiveMessageTwilioServiceApplication>(*args)
}
