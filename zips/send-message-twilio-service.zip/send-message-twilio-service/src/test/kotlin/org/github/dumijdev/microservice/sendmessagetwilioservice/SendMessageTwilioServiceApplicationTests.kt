package org.github.dumijdev.microservice.sendmessagetwilioservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SendMessageTwilioServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
