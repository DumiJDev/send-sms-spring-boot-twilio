package org.github.dumijdev.microservice.discoverymessagetwilioservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DiscoveryMessageTwilioServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
