package org.github.dumijdev.microservice.discoverymessagetwilioservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class DiscoveryMessageTwilioServiceApplication

fun main(args: Array<String>) {
	runApplication<DiscoveryMessageTwilioServiceApplication>(*args)
}
