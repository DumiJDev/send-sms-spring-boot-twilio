package org.github.dumijdev.microservice.receivemessagetwilioservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ReceiveMessageTwilioServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
