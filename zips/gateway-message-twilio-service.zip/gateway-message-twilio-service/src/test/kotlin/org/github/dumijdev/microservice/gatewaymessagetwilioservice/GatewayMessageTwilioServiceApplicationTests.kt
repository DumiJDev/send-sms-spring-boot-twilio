package org.github.dumijdev.microservice.gatewaymessagetwilioservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GatewayMessageTwilioServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
